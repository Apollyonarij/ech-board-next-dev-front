import { encryptSecret, type SecretKey } from '../io/crypto/secret'
import type { PostPartInput } from '../io/ech/protocol/types'
import { serializePostParts } from '../io/ech/protocol/types'

type VariantName = 'Bold' | 'Italic' | 'Underline' | 'Overline' | 'Spoiler' | 'Strike' | 'Sup' | 'Sub'

const TAG_MAP: Record<string, VariantName> = {
  b: 'Bold',
  i: 'Italic',
  u: 'Underline',
  o: 'Overline',
  spoiler: 'Spoiler',
  s: 'Strike',
  sup: 'Sup',
  sub: 'Sub',
}

export type PostRef = { forum?: string; board?: string; postNum: number }
export type ResolvedReply = { forum: Uint8Array; board: string; post: number; author?: Uint8Array }
export type PostResolver = (ref: PostRef) => Promise<ResolvedReply | null>

function parsePostRef(raw: string): PostRef | null {
  const parts = raw.split('/')
  if (parts.length > 1 && parts[0] === '') parts.shift()
  let forum: string | undefined
  let board: string | undefined
  let numStr: string
  if (parts.length === 1) {
    numStr = parts[0]
  } else if (parts.length === 2) {
    board = parts[0]
    numStr = parts[1]
  } else if (parts.length === 3) {
    forum = parts[0]
    board = parts[1]
    numStr = parts[2]
  } else {
    return null
  }
  if (!/^\d+$/.test(numStr)) return null
  return { forum: forum || undefined, board: board || undefined, postNum: parseInt(numStr, 10) }
}

export type ParsedPart =
  | { kind: 'plain'; text: string }
  | { kind: 'code'; text: string }
  | { kind: 'formatted'; variant: VariantName; children: ParsedPart[] }
  | { kind: 'secret'; children: ParsedPart[] }
  | { kind: 'secretRef'; index: number }
  | { kind: 'link'; url: string; children: ParsedPart[] }
  | { kind: 'fold'; title: string; children: ParsedPart[] }
  | { kind: 'reply'; forum: Uint8Array; board: string; post: number; author?: Uint8Array }

export async function parseBbCode(text: string, resolvePost?: PostResolver): Promise<ParsedPart[]> {
  const result: ParsedPart[] = []
  let i = 0

  while (i < text.length) {
    if (text[i] === '>' && text[i + 1] === '>' && resolvePost) {
      const start = i + 2
      let end = start
      while (end < text.length && /[A-Za-z0-9/:._-]/.test(text[end])) end++
      let raw = text.slice(start, end)
      while (raw.length > 0 && !/[A-Za-z0-9]/.test(raw[raw.length - 1])) raw = raw.slice(0, -1)
      const ref = parsePostRef(raw)
      const resolved = ref ? await resolvePost(ref) : null
      if (resolved) {
        result.push({ kind: 'reply', forum: resolved.forum, board: resolved.board, post: resolved.post, author: resolved.author })
        i = end
        continue
      }
      pushPlain(result, '>>')
      i += 2
      continue
    }

    if (text[i] !== '[') {
      let end = text.indexOf('[', i)
      if (end === -1) end = text.length
      const gtGt = resolvePost ? text.indexOf('>>', i) : -1
      if (gtGt !== -1 && gtGt < end) end = gtGt
      if (end > i) {
        pushPlain(result, text.slice(i, end))
      }
      i = end
      continue
    }

    const closeBracket = text.indexOf(']', i)
    if (closeBracket === -1) {
      pushPlain(result, text.slice(i))
      break
    }

    const tag = text.slice(i + 1, closeBracket)
    const closing = tag.startsWith('/')
    const tagName = closing ? tag.slice(1) : tag

    if (closing) {
      pushPlain(result, text[i])
      i++
      continue
    }

    const secretRef = /^secret_(\d+)$/.exec(tagName)
    if (secretRef) {
      result.push({ kind: 'secretRef', index: parseInt(secretRef[1], 10) })
      i = closeBracket + 1
      continue
    }

    if (tagName === 'secret') {
      const closeTag = '[/secret]'
      const endTag = text.indexOf(closeTag, closeBracket + 1)
      if (endTag === -1) {
        pushPlain(result, text.slice(i, closeBracket + 1))
        i = closeBracket + 1
        continue
      }
      const inner = text.slice(closeBracket + 1, endTag)
      const children = await parseBbCode(inner, resolvePost)
      result.push({ kind: 'secret', children })
      i = endTag + closeTag.length
      continue
    }

    if (tagName.startsWith('url=')) {
      const url = tag.slice(4)
      const closeTag = '[/url]'
      const endTag = text.indexOf(closeTag, closeBracket + 1)
      if (endTag === -1) {
        pushPlain(result, text.slice(i, closeBracket + 1))
        i = closeBracket + 1
        continue
      }
      const inner = text.slice(closeBracket + 1, endTag)
      const children = await parseBbCode(inner, resolvePost)
      result.push({ kind: 'link', url, children })
      i = endTag + closeTag.length
      continue
    }

    if (tagName.startsWith('fold=')) {
      const title = tag.slice(5)
      const endTag = findMatchingFoldClose(text, closeBracket + 1)
      if (endTag === -1) {
        pushPlain(result, text.slice(i, closeBracket + 1))
        i = closeBracket + 1
        continue
      }
      const inner = text.slice(closeBracket + 1, endTag)
      const children = await parseBbCode(inner, resolvePost)
      result.push({ kind: 'fold', title, children })
      i = endTag + FOLD_CLOSE.length
      continue
    }

    if (tagName === 'code') {
      const codeClose = '[/code]'
      const endTag = text.indexOf(codeClose, closeBracket + 1)
      if (endTag === -1) {
        pushPlain(result, text.slice(i, closeBracket + 1))
        i = closeBracket + 1
        continue
      }
      const inner = text.slice(closeBracket + 1, endTag)
      result.push({ kind: 'code', text: inner })
      i = endTag + codeClose.length
      continue
    }

    const variant = TAG_MAP[tagName]
    if (!variant) {
      pushPlain(result, text[i])
      i++
      continue
    }

    const closeTag = `[/${tagName}]`
    const endTag = findMatchingClose(text, tagName, closeBracket + 1)
    if (endTag === -1) {
      pushPlain(result, text.slice(i, closeBracket + 1))
      i = closeBracket + 1
      continue
    }

    const inner = text.slice(closeBracket + 1, endTag)
    const children = await parseBbCode(inner, resolvePost)
    result.push({ kind: 'formatted', variant, children })
    i = endTag + closeTag.length
  }

  return result
}

function pushPlain(result: ParsedPart[], text: string) {
  const last = result[result.length - 1]
  if (last && last.kind === 'plain') {
    last.text += text
  } else {
    result.push({ kind: 'plain', text })
  }
}

const FOLD_OPEN = '[fold='
const FOLD_CLOSE = '[/fold]'

function findMatchingFoldClose(text: string, from: number): number {
  let depth = 1
  let pos = from
  while (pos < text.length) {
    const nextOpen = text.indexOf(FOLD_OPEN, pos)
    const nextClose = text.indexOf(FOLD_CLOSE, pos)
    if (nextClose === -1) return -1
    if (nextOpen !== -1 && nextOpen < nextClose) {
      depth++
      pos = nextOpen + FOLD_OPEN.length
      continue
    }
    depth--
    if (depth === 0) return nextClose
    pos = nextClose + FOLD_CLOSE.length
  }
  return -1
}

function findMatchingClose(text: string, tagName: string, from: number): number {
  const open = `[${tagName}]`
  const close = `[/${tagName}]`
  let depth = 1
  let pos = from
  while (pos < text.length) {
    const nextOpen = text.indexOf(open, pos)
    const nextClose = text.indexOf(close, pos)
    if (nextClose === -1) return -1
    if (nextOpen !== -1 && nextOpen < nextClose) {
      depth++
      pos = nextOpen + open.length
      continue
    }
    depth--
    if (depth === 0) return nextClose
    pos = nextClose + close.length
  }
  return -1
}

export async function finalizeParts(
  parts: ParsedPart[],
  secret: SecretKey | null,
  secretRefs?: Map<number, PostPartInput>,
): Promise<PostPartInput[]> {
  const seen = new Set<string>()
  const replyKeys: Uint8Array[] = []
  collectReplyKeys(parts, seen, replyKeys)

  return convertParts(parts, secret, replyKeys, secretRefs)
}

function collectReplyKeys(parts: ParsedPart[], seen: Set<string>, replyKeys: Uint8Array[]) {
  for (const p of parts) {
    if (p.kind === 'reply') {
      if (p.author && p.author.length === 96) {
        const point = p.author.slice(32, 64)
        const hex = Array.from(point, b => b.toString(16).padStart(2, '0')).join('')
        if (!seen.has(hex)) {
          seen.add(hex)
          replyKeys.push(point)
        }
      }
    } else if (p.kind === 'formatted' || p.kind === 'link' || p.kind === 'fold') {
      collectReplyKeys(p.children, seen, replyKeys)
    } else if (p.kind === 'secret') {
      collectReplyKeys(p.children, seen, replyKeys)
    }
  }
}

async function convertParts(
  parts: ParsedPart[],
  secret: SecretKey | null,
  replyKeys: Uint8Array[],
  secretRefs?: Map<number, PostPartInput>,
): Promise<PostPartInput[]> {
  const out: PostPartInput[] = []
  for (const p of parts) {
    if (p.kind === 'plain') {
      out.push({ Plain: p.text })
    } else if (p.kind === 'code') {
      out.push({ Code: p.text })
    } else if (p.kind === 'reply') {
      out.push({ ReplyTo: { forum: p.forum, board: p.board, post: p.post } })
    } else if (p.kind === 'secretRef') {
      const orig = secretRefs?.get(p.index)
      if (orig) out.push(orig)
    } else if (p.kind === 'secret') {
      if (!secret) continue
      const children = await convertParts(p.children, secret, replyKeys, secretRefs)
      const data = serializePostParts(children)
      out.push(await encryptSecret(data, secret, replyKeys))
    } else if (p.kind === 'link') {
      const children = await convertParts(p.children, secret, replyKeys, secretRefs)
      out.push({ Link: { url: p.url, children } })
    } else if (p.kind === 'fold') {
      const children = await convertParts(p.children, secret, replyKeys, secretRefs)
      out.push({ Fold: { title: p.title, children } })
    } else if (p.kind === 'formatted') {
      const children = await convertParts(p.children, secret, replyKeys, secretRefs)
      out.push({ [p.variant]: children } as PostPartInput)
    }
  }
  return out
}

export function firstPlainLine(parts: PostPartInput[]): string {
  for (const p of parts) {
    const s = firstPlainLineOfPart(p)
    if (s && s.trim()) return s
  }
  return ''
}

function firstPlainLineOfPart(p: PostPartInput): string | null {
  if ('Plain' in p) return p.Plain
  if ('Bold' in p) return firstPlainLine(p.Bold)
  if ('Italic' in p) return firstPlainLine(p.Italic)
  if ('Underline' in p) return firstPlainLine(p.Underline)
  if ('Overline' in p) return firstPlainLine(p.Overline)
  if ('Spoiler' in p) return firstPlainLine(p.Spoiler)
  if ('Strike' in p) return firstPlainLine(p.Strike)
  if ('Sup' in p) return firstPlainLine(p.Sup)
  if ('Sub' in p) return firstPlainLine(p.Sub)
  if ('Fold' in p) return p.Fold.title || firstPlainLine(p.Fold.children)
  return null
}
