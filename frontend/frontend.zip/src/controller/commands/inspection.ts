import { untrack } from 'solid-js'
import { toHex } from '../../model/content/hex'
import { type EntityKind } from '../../model/entities/entity'
import { describeError } from '../../model/errors'
import { identityKey } from '../../model/rules/identity'
import type { ForumState } from '../../model/state/forum'
import type { HistoryKind } from '../../model/state/inspection'
import { resourceKey } from '../../model/state/resources'
import type { Commit } from '../commit'
import { formatDebugValue } from '../convert/debug'
import type { ForumGateway } from '../forumGateway'
import { fetchBans, fetchEntitySnapshot, fetchHistory } from '../io/ech/admin'
import { convertHistory } from '../convert/history'
import { txAuthor } from '../convert/genesis'

export function createInspectionCommands(model: ForumState, commit: Commit, gateway: ForumGateway) {
  const requests = new Map<string, { id: number; page: number }>()
  let nextRequest = 0
  let disposed = false
  const begin = (key: string) => { const id = ++nextRequest; requests.set(key, { id, page: model.page.revision }); return id }
  const current = (key: string, id: number) => !disposed && requests.get(key)?.id === id && requests.get(key)?.page === model.page.revision
  const finish = (key: string, id: number) => { if (requests.get(key)?.id === id) requests.delete(key) }

  return {
    async transaction(relayUrl: string, txid: string) {
      const api = await gateway.connect(relayUrl)
      const transactions = await api.transactions([txid])
      return transactions.get(`0x${txid.replace(/^0x/, '')}`) ?? null
    },
    async loadBans(relayUrl: string, kind: EntityKind, id: string) {
      if (kind === 'post') return
      const key = resourceKey(relayUrl, kind, id)
      const request = begin(`bans:${key}`)
      commit({ type: 'bans.set', value: { key, value: { items: [], loading: true, error: null } } })
      try {
        const api = await gateway.connect(relayUrl)
        const { view: bans, contents } = await fetchBans(api, kind, id)
        const transactions = await api.transactions(bans.map((ban) => toHex(ban.target)))
        if (!current(`bans:${key}`, request)) return
        const items = bans.map((ban) => {
          const target = toHex(ban.target)
          const tx = transactions.get(target)
          const author = tx ? txAuthor(tx) : null
          if (author === null) throw new Error(`Missing transaction ${target}`)
          const hash = ban.reason_hash ? toHex(ban.reason_hash) : null
          const bytes = hash ? contents.get(hash) : null
          const reason = hash === null ? null : bytes ? new TextDecoder().decode(bytes) : hash
          return { target, author: identityKey(author), reason, expires: ban.expires === null ? null : Number(ban.expires) }
        })
        commit({ type: 'bans.set', value: { key, value: { items, loading: false, error: null } } })
      } catch (error) {
        if (current(`bans:${key}`, request)) commit({ type: 'bans.set', value: { key, value: { items: [], loading: false, error: describeError(error) } } })
      } finally {
        finish(`bans:${key}`, request)
      }
    },
    async loadSnapshot(relayUrl: string, kind: EntityKind, id: string) {
      const key = resourceKey(relayUrl, kind, id)
      const request = begin(`snapshot:${key}`)
      commit({ type: 'snapshot.set', value: { key, value: { data: null, loading: true, error: null } } })
      try {
        const snapshot = await fetchEntitySnapshot(relayUrl, kind, id)
        if (!current(`snapshot:${key}`, request)) return
        commit({ type: 'snapshot.set', value: { key, value: { data: { id: snapshot.id, hex: toHex(snapshot.bytes), entity: formatDebugValue(snapshot.entity) }, loading: false, error: null } } })
      } catch (error) {
        if (current(`snapshot:${key}`, request)) commit({ type: 'snapshot.set', value: { key, value: { data: null, loading: false, error: describeError(error) } } })
      } finally {
        finish(`snapshot:${key}`, request)
      }
    },
    async loadHistory(relayUrl: string, kind: HistoryKind, id: string, more = false) {
      const key = resourceKey(relayUrl, kind, id)
      const previous = untrack(() => model.resources.history[key])
      if (more && (!previous?.next || previous.loading || previous.loadingMore)) return
      const request = begin(`history:${key}`)
      const items = more ? previous.items.slice() : []
      commit({ type: 'history.set', value: { key, value: { items, next: more ? previous.next : null, loading: !more, loadingMore: more, error: null } } })
      try {
        const page = await fetchHistory(relayUrl, kind, id, more ? previous.next : null)
        if (!current(`history:${key}`, request)) return
        const lastNumber = items.at(-1)?.number ?? null
        const firstNumber = more ? (lastNumber === null ? null : lastNumber - 1n) : page.length
        const entries = page.entries.map((tx, index) => convertHistory(tx, firstNumber === null ? null : firstNumber - BigInt(index)))
        commit({ type: 'history.set', value: { key, value: { items: [...items, ...entries], next: page.next, loading: false, loadingMore: false, error: null } } })
      } catch (error) {
        if (current(`history:${key}`, request)) commit({ type: 'history.set', value: { key, value: { items, next: more ? previous.next : null, loading: false, loadingMore: false, error: describeError(error) } } })
      } finally {
        finish(`history:${key}`, request)
      }
    },
    disposeInspection() { disposed = true; requests.clear() },
  }
}
