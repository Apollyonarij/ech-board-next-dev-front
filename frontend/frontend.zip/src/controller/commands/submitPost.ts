import { blake2b } from '@noble/hashes/blake2'
import { requestsPostcount } from '../../model/content/requests'
import { describeError } from '../../model/errors'
import type { RoleOption } from '../../model/rules/roles'
import type { ComposerDraft } from '../../model/state/composer'
import type { ForumState } from '../../model/state/forum'
import { finalizeParts, parseBbCode } from '../content/bbcode'
import { makePostResolver } from '../content/postResolver'
import type { ForumGateway } from '../forumGateway'
import { Calls, type Call, type ForumApi } from '../io/ech/forumApi'
import { EntityId } from '../io/ech/protocol/entityId'
import { PostKeySchema, ThreadKeySchema, type UserRequests } from '../io/ech/protocol/entities'
import { randomTweak } from '../io/crypto/identity'
import { serializePostParts } from '../io/ech/protocol/types'
import * as relayApi from '../io/ech/relay'
import type { EntityUpdate } from '../state/entities.types'

const text = new TextEncoder()

function postTweak(role?: RoleOption): Uint8Array {
  return role?.tweak ?? randomTweak()
}

export interface PostSubmitCtx {
  gateway: ForumGateway
  model: ForumState
  receive: (changes: EntityUpdate) => void
  forumId: string
  relayUrl: string
  boardId: string
  slug: string
  role?: RoleOption
}

export interface PostFormState {
  text: string
  name: string
  withFlag: boolean
  files: File[]
  stripExif: boolean
  selfAdmin?: boolean
}

export function composerForm(draft: ComposerDraft): PostFormState {
  return { text: draft.text, name: draft.name, withFlag: draft.withFlag, files: draft.files.slice(), stripExif: draft.stripExifOn, selfAdmin: draft.selfAdmin }
}

export type Progress = (loaded: number, total: number) => void

async function uploadAll(files: File[], onProgress: Progress): Promise<{ hashes: string[]; blobs: Uint8Array[] }> {
  const hashes: string[] = []
  const blobs: Uint8Array[] = []
  let loaded = 0
  for (const file of files) {
    const bytes = new Uint8Array(await file.arrayBuffer())
    hashes.push(relayApi.hex(blake2b(bytes, { dkLen: 32 })))
    blobs.push(bytes)
    loaded += 1
    onProgress(loaded, files.length)
  }
  return { hashes, blobs }
}

function textBlob(value: string): { hash: string; blob: Uint8Array } | null {
  if (!value.trim()) return null
  const bytes = text.encode(value)
  return { hash: relayApi.hex(blake2b(bytes, { dkLen: 32 })), blob: bytes }
}

function splitName(value: string): { name: string; trip: string | null } {
  const index = value.indexOf('#')
  if (index < 0) return { name: value, trip: null }
  return { name: value.slice(0, index), trip: value.slice(index) }
}

function powBits(ctx: PostSubmitCtx): number {
  const scope = ctx.model.scopes[ctx.forumId]
  const board = scope?.entities.boards[ctx.boardId]?.powBits ?? 0
  const forum = scope?.entities.forums[ctx.forumId]?.powBits ?? 0
  return Math.max(board, forum)
}

function powRequired(error: unknown): boolean {
  const failure = describeError(error)
  return typeof failure !== 'string' && failure.code === 'PowRequired'
}

async function append(
  ctx: PostSubmitCtx,
  api: ForumApi,
  entry: {
    call: Call
    blobs: { hash: string; bytes: Uint8Array }[]
    tweak: Uint8Array
    requests: UserRequests
    trip: string | null
  },
): Promise<{ txid: string; result: Uint8Array }> {
  try {
    return await api.append(entry.call, entry.blobs, entry.tweak, undefined, entry.requests, entry.trip)
  } catch (error) {
    const bits = powBits(ctx)
    if (bits === 0 || !powRequired(error)) throw error
    return await api.append(entry.call, [], entry.tweak, undefined, entry.requests, entry.trip, bits)
  }
}

async function prepare(
  ctx: PostSubmitCtx,
  form: PostFormState,
  onProgress: Progress,
  tweak: Uint8Array,
): Promise<{ textHash: string | null; media: string[]; nameHash: string | null; trip: string | null; postcount: boolean; blobs: Uint8Array[] }> {
  const api = await ctx.gateway.connect(ctx.relayUrl)
  const parsed = await parseBbCode(
    form.text,
    makePostResolver({
      gateway: ctx.gateway,
      model: ctx.model,
      forumId: ctx.forumId,
      boardId: ctx.boardId,
      slug: ctx.slug,
      relayUrl: ctx.relayUrl,
      receive: ctx.receive,
    }),
  )
  const secret = api.identity.secret(api.root, tweak)
  const parts = await finalizeParts(parsed, secret)
  const blobs: Uint8Array[] = []
  let hash: string | null = null
  if (parts.length > 0) {
    const blob = serialize(parts)
    blobs.push(blob)
    hash = relayApi.hex(blake2b(blob, { dkLen: 32 }))
  }
  const media = await uploadAll(form.files, onProgress)
  blobs.push(...media.blobs)
  const name = splitName(form.name)
  const blob = textBlob(name.name)
  if (blob) blobs.push(blob.blob)
  return { textHash: hash, media: media.hashes, nameHash: blob ? blob.hash : null, trip: name.trip, postcount: requestsPostcount(parts), blobs }
}

function serialize(parts: unknown): Uint8Array {
  return serializePostParts(parts as never)
}

export async function submitNewThread(
  ctx: PostSubmitCtx,
  form: PostFormState,
  subject: string,
  onProgress: Progress,
  _signal?: AbortSignal,
): Promise<{ thread: number } | null> {
  const tweak = postTweak(ctx.role)
  const { textHash: hash, media, nameHash, trip, postcount, blobs } = await prepare(ctx, form, onProgress, tweak)
  const api = await ctx.gateway.connect(ctx.relayUrl)
  const topic = textBlob(subject)
  if (topic) blobs.push(topic.blob)
  const result = await append(ctx, api, {
    call: Calls.thread.create(ctx.boardId, topic ? topic.hash : null, hash, media, nameHash, [], false, !!form.selfAdmin),
    blobs: blobs.map((bytes) => ({ hash: '', bytes })),
    tweak,
    requests: { geo: form.withFlag, trip: trip !== null, postcount },
    trip,
  })
  return { thread: Number(ThreadKeySchema.parse(result.result).number) }
}

export async function submitReply(
  ctx: PostSubmitCtx & { threadId: string; threadNumber: number },
  form: PostFormState,
  onProgress: Progress,
  _signal?: AbortSignal,
): Promise<{ post: number } | null> {
  const tweak = postTweak(ctx.role)
  const { textHash: hash, media, nameHash, trip, postcount, blobs } = await prepare(ctx, form, onProgress, tweak)
  const api = await ctx.gateway.connect(ctx.relayUrl)
  const result = await append(ctx, api, {
    call: Calls.post.create(ctx.boardId, EntityId.thread(ctx.slug, ctx.threadNumber), hash, media, nameHash, [], false),
    blobs: blobs.map((bytes) => ({ hash: '', bytes })),
    tweak,
    requests: { geo: form.withFlag, trip: trip !== null, postcount },
    trip,
  })
  return { post: Number(PostKeySchema.parse(result.result).number) }
}
